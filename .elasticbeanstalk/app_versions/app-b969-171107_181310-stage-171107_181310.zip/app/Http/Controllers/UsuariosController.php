<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Usuario;

class UsuariosController extends Controller
{
    public function ranking_referidos()
    {
        //$us=Usuario
    }
}
