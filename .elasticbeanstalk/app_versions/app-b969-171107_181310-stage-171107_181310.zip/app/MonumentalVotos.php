<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MonumentalVotos extends Model
{
    protected $table = 'monumentales_votos';
	protected $guarded = ['id'];

//relaciones
}
