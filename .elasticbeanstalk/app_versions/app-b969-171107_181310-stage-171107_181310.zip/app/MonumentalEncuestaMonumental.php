<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MonumentalEncuestaMonumental extends Model
{
    protected $table = 'monumental_monumental_encuesta';
	protected $guarded = ['id'];
    public $timestamps = false;

//relaciones
}
