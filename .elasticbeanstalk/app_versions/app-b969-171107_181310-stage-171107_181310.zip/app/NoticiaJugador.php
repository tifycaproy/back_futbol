<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class NoticiaJugador extends Model
{
    protected $table = 'noticias_jugadores';
	protected $guarded = ['id'];
    public $timestamps = false;

//relaciones
}
