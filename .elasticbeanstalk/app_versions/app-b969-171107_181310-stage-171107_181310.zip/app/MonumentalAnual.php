<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MonumentalAnual extends Model
{
    protected $table = 'monumentales_anual';
	protected $guarded = ['id'];

//relaciones
}
