<!DOCTYPE html>
<html>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<head>
 	<title>Juramento</title>

<style>


#texto{

text-align: justify;
text-align: center;
font-family: sans-serif;
font-size: 20px;


}

</style>

</head>
<body bgcolor= "#FFD900" bgwidth:"2px" height:"20px">
<center> 

 
<?php
$texto = "Juro ser amarillo de nacimiento y pertenecer <br> de corazón al único Ídolo del Ecuador, <br> Barcelona Sporting Club. <br> Si es así, haz click aquí";


   
  echo "<br>";
  echo "<div id=\"texto\">";
  echo $texto;
  echo "</div>";
  
  
?> 
</center>
</div>	
	</body>
</html>